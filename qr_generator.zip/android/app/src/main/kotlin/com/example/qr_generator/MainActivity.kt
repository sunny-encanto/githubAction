package com.example.qr_generator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
